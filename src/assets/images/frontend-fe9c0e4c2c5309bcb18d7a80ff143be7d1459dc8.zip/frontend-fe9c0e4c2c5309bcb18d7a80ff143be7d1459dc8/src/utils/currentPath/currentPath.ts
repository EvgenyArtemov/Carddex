const currentPath = (): string => {
    return window.location.pathname;
};

export default currentPath;
