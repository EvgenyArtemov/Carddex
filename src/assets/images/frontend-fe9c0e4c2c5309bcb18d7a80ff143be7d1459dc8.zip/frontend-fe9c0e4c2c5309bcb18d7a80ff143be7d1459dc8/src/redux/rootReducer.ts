import { combineReducers } from 'redux';
import AppReducer from 'App/appReducer';
import SideNavReducer from 'App/components/global/SideNav/sideNavReducer';
import SecurityPostCentralReducer from 'App/components/pages/SecurityPost/SecurityPostCentral/securityPostCentralReducer';
import SecurityAttendanceReducer from 'App/components/pages/SecurityPost/SecurityAttendance/securityAttendanceReducer'
import ReportsEventsReducer from 'App/components/pages/Reports/ReportsEvents/reportsEventsReducer';
import StaffDepartmentsReducer from 'App/components/pages/Staff/StaffDepartments/staffDepartmentsReducer';
import StaffEmployeesReducer from 'App/components/pages/Staff/StaffEmployees/staffEmployeesReducer';
import StaffOrganizationsReducer from 'App/components/pages/Staff/StaffOrganizations/staffOrganizationsReducer';
import SecurityPostMonitoringReducer from 'App/components/pages/SecurityPost/SecurityPostMonitoring/securityPostMonitoringReducer';
import ReportsWorkingTimeReducer from 'App/components/pages/Reports/ReportsWorkingTime/reportsWorkingTimeReducer';
import ReportsDeviationsReducer from 'App/components/pages/Reports/ReportsDeviations/reportsDeviationsReducer';
import ReportsStatisticsReducer from 'App/components/pages/Reports/ReportsStatistics/reportsStatisticsReducer';
import EmployeeTimetableReducer from 'App/components/pages/Staff/StaffEmployees/EmployeeTimetable/employeeTimetableReducer';

const rootReducer = combineReducers({
    app: AppReducer,
    sideNav: SideNavReducer,
    postCental: SecurityPostCentralReducer,
    attendance: SecurityAttendanceReducer,
    reportsEvents: ReportsEventsReducer,
    departments: StaffDepartmentsReducer,
    employees: StaffEmployeesReducer,
    organizations: StaffOrganizationsReducer,
    monitoringEvents: SecurityPostMonitoringReducer,
    workingTime: ReportsWorkingTimeReducer,
    deviations: ReportsDeviationsReducer,
    statistics: ReportsStatisticsReducer,
    employeeTimetable: EmployeeTimetableReducer
});

export default rootReducer;
