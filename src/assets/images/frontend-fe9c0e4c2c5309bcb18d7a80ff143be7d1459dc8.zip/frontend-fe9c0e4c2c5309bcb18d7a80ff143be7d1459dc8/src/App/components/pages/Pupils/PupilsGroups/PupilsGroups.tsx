import React from 'react';
import './PupilsGroups.scss';

const PupilsGroups = () => {
    return (
        <div className="pupils-groups">
            <h1>Скоро тут будут</h1>
            <p>"Группы учащихся"</p>
        </div>
    );
};

export default PupilsGroups;
