import React from 'react';
import './SettingsProfile.scss';

const SettingsProfile = () => {
    return (
        <div className="settings-profile">
            <span>123</span>
        </div>
    );
};

export default SettingsProfile;
