const addProps = {
    successButtonLabel: 'Добавить',
    declineButtonLabel: 'Отмена'
};

export default addProps;
