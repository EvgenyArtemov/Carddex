import React from 'react';
import './IdentifiersBiometrics.scss';

const IdentifiersBiometrics = () => {
    return (
        <div className="identifiers-biometrics">
            <span>123</span>
        </div>
    );
};

export default IdentifiersBiometrics;
