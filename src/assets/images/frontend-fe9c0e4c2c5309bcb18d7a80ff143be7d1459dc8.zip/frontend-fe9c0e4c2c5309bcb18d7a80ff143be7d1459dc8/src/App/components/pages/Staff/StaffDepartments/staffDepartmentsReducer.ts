import {
    StaffDepartmentsState,
    StaffDepartmentsActions,
    GET_STAFF_DEPARTMENTS
} from './staffDepartmentsTypes';

const initialState: StaffDepartmentsState = {
    staffDepartments: []
};

const staffDepartments = (state = initialState, action: StaffDepartmentsActions): StaffDepartmentsState => {
    switch (action.type) {
        case GET_STAFF_DEPARTMENTS:
            return {
                ...state,
                staffDepartments: action.payload
            };
        default:
            return state;
    }
};

export default staffDepartments;
