import React from 'react';
import './SettingsDatabase.scss';

const SettingsDatabase = () => {
    return (
        <div className="settings-database">
            <span>123</span>
        </div>
    );
};

export default SettingsDatabase;
