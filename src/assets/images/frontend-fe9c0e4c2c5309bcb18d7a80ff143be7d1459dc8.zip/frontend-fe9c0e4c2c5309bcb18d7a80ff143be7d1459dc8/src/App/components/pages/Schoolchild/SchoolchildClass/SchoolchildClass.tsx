import React from 'react';
import './SchoolchildClass.scss';

const SchoolchildClass = () => {
    return (
        <div className="schoolchild-class">
            <h1>Скоро тут будут</h1>
            <p>"Классы учеников"</p>
        </div>
    );
};

export default SchoolchildClass;
