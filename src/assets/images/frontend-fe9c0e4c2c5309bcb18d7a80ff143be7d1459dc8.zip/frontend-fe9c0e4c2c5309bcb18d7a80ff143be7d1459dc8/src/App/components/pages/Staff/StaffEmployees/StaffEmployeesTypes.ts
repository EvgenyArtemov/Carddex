export interface StaffEmployee {
    uuid: string;
    name: string;
    occupation: null;
}

export type StaffEmployees = Array<StaffEmployee>;

export interface StaffEmployeesState {
    staffEmployees: StaffEmployees;
}

export const GET_STAFF_EMPLOYEES = 'GET_STAFF_EMPLOYEES';

interface StaffEmployeesData {
    type: typeof GET_STAFF_EMPLOYEES;
    payload: StaffEmployees;
}

export type StaffEmployeesActions = StaffEmployeesData;
