import React from 'react';
import './SettingsUsersAndRoles.scss';

const SettingsUsersAndRoles = () => {
    return (
        <div className="settings-users-and-roles">
            <span>123</span>
        </div>
    );
};

export default SettingsUsersAndRoles;
