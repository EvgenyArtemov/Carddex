import {
    StaffOrganizationsState,
    StaffOrganizationsActions,
    GET_STAFF_ORGANIZATIONS,
    STAF_ORGANIZATIONS_TOGGLE_SIDEBAR
} from './staffOrganizationsTypes';

const initialState: StaffOrganizationsState = {
    staffOrganizations: [],
    sidebarOpened: false
};

const staffOrganizations = (state = initialState, action: StaffOrganizationsActions): StaffOrganizationsState => {
    switch (action.type) {
        case GET_STAFF_ORGANIZATIONS:
            return {
                ...state,
                staffOrganizations: action.payload
            };
        case STAF_ORGANIZATIONS_TOGGLE_SIDEBAR:
            return {
                ...state,
                sidebarOpened: !state.sidebarOpened
            };
        default:
            return state;
    }
};

export default staffOrganizations;
