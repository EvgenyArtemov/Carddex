import React from 'react';
import './Breadcrumb.scss';

const Breadcrumb = () => {
    return (
        <div className="breadcrumb">
            <span>123</span>
        </div>
    );
};

export default Breadcrumb;
