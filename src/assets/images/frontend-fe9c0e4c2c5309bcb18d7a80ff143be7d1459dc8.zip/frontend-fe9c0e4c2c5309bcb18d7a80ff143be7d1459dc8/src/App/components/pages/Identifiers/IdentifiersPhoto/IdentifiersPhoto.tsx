import React from 'react';
import './IdentifiersPhoto.scss';

const IdentifiersPhoto = () => {
    return (
        <div className="identifiers-photo">
            <span>123</span>
        </div>
    );
};

export default IdentifiersPhoto;
