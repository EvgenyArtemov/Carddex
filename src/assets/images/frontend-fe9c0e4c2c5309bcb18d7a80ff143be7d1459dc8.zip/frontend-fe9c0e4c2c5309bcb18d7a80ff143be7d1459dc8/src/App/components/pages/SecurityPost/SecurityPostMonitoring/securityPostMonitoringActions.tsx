import axios from 'axios';
import { Dispatch } from 'react';
import {
    SecurityPostMonitoringEvents,
    SecurityPostMonitoringActions,
    GET_SECURITY_POST_MONITORING_EVENTS
} from './securityPostMonitoringTypes';
import config from '../../../../../config/config.json';

const getSecurityPostMonitoringEvents = (eventsList: SecurityPostMonitoringEvents): SecurityPostMonitoringActions => {
    return {
        type: GET_SECURITY_POST_MONITORING_EVENTS,
        payload: eventsList
    };
};

export const requestSecurityPostMonitoringEvents = () => async (dispatch: Dispatch<SecurityPostMonitoringActions>) => {
    try {
        const res = await axios.get(`${config.apiUrl}monitoring/base/online?count=100`);
        dispatch(getSecurityPostMonitoringEvents(res.data.list));
    } catch (e) {
        console.log(e.body);
    }
};
