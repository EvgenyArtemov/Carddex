import React from 'react';
import './SettingsTerritoryZoning.scss';

const SettingsTerritoryZoning = () => {
    return (
        <div className="settings-territory-zoning">
            <span>123</span>
        </div>
    );
};

export default SettingsTerritoryZoning;
