import React from 'react';
import './PupilsStudents.scss';

const PupilsStudents = () => {
    return (
        <div className="pupils-students">
            <h1>Скоро тут будет</h1>
            <p>"Список студентов"</p>
        </div>
    );
};

export default PupilsStudents;
