import React from 'react';
import './SchoolchildStudents.scss';

const SchoolchildStudents = () => {
    return (
        <div className="schoolchild-students">
            <h1>Скоро тут будет</h1>
            <p>"Список учеников"</p>
        </div>
    );
};

export default SchoolchildStudents;
