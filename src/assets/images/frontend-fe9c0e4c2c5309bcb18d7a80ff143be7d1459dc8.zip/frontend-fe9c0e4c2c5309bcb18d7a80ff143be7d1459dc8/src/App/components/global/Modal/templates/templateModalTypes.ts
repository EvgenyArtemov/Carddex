export interface TemplateModalProps {
    modalName: string;
    modalHeader?: string;
}
