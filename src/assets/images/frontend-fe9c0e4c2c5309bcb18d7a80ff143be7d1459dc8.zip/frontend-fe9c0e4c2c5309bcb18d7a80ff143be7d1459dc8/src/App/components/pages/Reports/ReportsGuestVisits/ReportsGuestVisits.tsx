import React from 'react';
import './ReportsGuestVisits.scss';

const ReportsGuestVisits = () => {
    return (
        <div className="reports-guest-visits">
            <span>123</span>
        </div>
    );
};

export default ReportsGuestVisits;
