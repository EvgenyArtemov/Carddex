import React from 'react';
import './SettingsEquipment.scss';

const SettingsEquipment = () => {
    return (
        <div className="settings-equipment">
            <span>123</span>
        </div>
    );
};

export default SettingsEquipment;
