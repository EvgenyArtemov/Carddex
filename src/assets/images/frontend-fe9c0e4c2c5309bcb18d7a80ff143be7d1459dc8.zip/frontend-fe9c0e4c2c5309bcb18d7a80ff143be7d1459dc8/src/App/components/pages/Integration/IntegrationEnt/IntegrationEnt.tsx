import React from 'react'

const IntegrationEnt = () => {
    return (
        <div>123</div>
    )
}

export default IntegrationEnt
