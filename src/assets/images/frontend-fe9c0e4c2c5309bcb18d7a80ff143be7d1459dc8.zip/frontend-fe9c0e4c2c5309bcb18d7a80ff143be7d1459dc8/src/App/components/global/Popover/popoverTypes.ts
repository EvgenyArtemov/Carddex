import React from 'react';

export default interface PopoverProps {
    children: React.ReactNode;
}
