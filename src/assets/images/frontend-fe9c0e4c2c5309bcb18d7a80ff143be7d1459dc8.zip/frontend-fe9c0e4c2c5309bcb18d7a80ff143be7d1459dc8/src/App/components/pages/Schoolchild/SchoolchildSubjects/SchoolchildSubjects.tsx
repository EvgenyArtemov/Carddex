import React from 'react';
import './SchoolchildSubjects.scss';

const SchoolchildSubjects = () => {
    return (
        <div className="schoolchild-subjects">
            <h1>Скоро тут будут</h1>
            <p>"Предметы"</p>
        </div>
    );
};

export default SchoolchildSubjects;
