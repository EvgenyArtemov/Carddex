const editProps = {
    successButtonLabel: 'Сохранить',
    declineButtonLabel: 'Отмена'
};

export default editProps;
