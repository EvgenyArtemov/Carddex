# Toolbar

### Props

```ts
    interface ToolbarProps {
        toolbarStyles?: CSSProperties;
        toolbarContentStyles?: CSSProperties;
    }
```