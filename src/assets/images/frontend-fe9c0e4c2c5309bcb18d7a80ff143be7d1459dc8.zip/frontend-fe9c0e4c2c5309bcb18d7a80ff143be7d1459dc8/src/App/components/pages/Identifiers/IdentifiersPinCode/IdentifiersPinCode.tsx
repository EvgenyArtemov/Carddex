import React from 'react';
import './IdentifiersPinCode.scss';

const IdentifiersPinCode = () => {
    return (
        <div className="identifiers-pincode">
            <span>123</span>
        </div>
    );
};

export default IdentifiersPinCode;
