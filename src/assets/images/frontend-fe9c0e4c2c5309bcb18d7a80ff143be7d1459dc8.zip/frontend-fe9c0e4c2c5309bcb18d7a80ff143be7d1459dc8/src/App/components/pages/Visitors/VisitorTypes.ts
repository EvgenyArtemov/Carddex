export type Visitors = Array<Visitor>;

export interface Visitor {
    _id: string;
    fio: string;
    contactPhone: string;
    validity: string;
}
