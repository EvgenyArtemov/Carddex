import React from 'react';
import './SchoolchildSchedules.scss';

const SchoolchildSchedules = () => {
    return (
        <div className="schoolchild-schedules">
            <h1>Скоро тут будут</h1>
            <p>"Расписания учеников"</p>
        </div>
    );
};

export default SchoolchildSchedules;
