import React from 'react';

export const EventsFilters = () => {
    return (
        <section className="monitoring-params__content">
            <div className="content__items">Наполнение страницы</div>
        </section>
    );
};
