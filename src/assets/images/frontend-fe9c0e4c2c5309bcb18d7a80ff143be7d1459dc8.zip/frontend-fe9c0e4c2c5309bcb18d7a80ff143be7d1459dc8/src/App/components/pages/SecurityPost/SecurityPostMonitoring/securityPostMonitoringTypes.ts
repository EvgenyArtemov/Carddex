export type SecurityPostMonitoringEvents = Array<EventInfo>;

export interface EventInfo {
    eventDate: string;
    physpersonName: string;
    physpersonUuid: string;
    eventCodeName: string;
    sourceName: string;
}

export interface SecurityPostMonitoringState {
    events: SecurityPostMonitoringEvents;
}

export const GET_SECURITY_POST_MONITORING_EVENTS = 'GET_SECURITY_POST_MONITORING_EVENTS';

interface SecurityPostMonitoringData {
    type: typeof GET_SECURITY_POST_MONITORING_EVENTS;
    payload: SecurityPostMonitoringEvents;
}

export type SecurityPostMonitoringActions = SecurityPostMonitoringData;
