export interface CustomScrollbarState {    
    children: any;
    trigger?: boolean;
}