import React from 'react';
import './PupilsSchedules.scss';

const PupilsSchedules = () => {
    return (
        <div className="pupils-schedules">
            <h1>Скоро тут будут</h1>
            <p>"Расписания учащихся"</p>
        </div>
    );
};

export default PupilsSchedules;
