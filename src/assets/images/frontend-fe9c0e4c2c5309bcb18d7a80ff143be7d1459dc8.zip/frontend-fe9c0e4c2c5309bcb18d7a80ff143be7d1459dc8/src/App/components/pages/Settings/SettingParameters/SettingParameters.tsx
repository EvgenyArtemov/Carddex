import React from 'react';
import './SettingParameters.scss';

const SettingParameters = () => {
    return (
        <div className="setting-parameters">
            <span>123</span>
        </div>
    );
};

export default SettingParameters;
