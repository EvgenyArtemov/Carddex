import React from 'react';
import './PupilsFaculties.scss';

const PupilsFaculties = () => {
    return (
        <div className="pupils-faculties">
            <h1>Скоро тут будут</h1>
            <p>"Факультеты учащихся"</p>
        </div>
    );
};

export default PupilsFaculties;
