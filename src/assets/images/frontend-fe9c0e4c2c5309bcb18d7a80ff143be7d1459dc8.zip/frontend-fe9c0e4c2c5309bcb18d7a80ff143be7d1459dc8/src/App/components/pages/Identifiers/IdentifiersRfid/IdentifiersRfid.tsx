import React from 'react';
import './IdentifiersRfid.scss';

const IdentifiersRfid = () => {
    return (
        <div className="identifiers-rfid">
            <span>123</span>
        </div>
    );
};

export default IdentifiersRfid;
