import { CSSProperties } from 'react';

export interface ToolbarProps {
    toolbarStyles?: CSSProperties;
    toolbarContentStyles?: CSSProperties;
    children?: any;
}
