import React, { useRef, useEffect } from 'react';
import { Button } from 'primereact/button';
import { SideNavIcon } from '../SideNav/SideNavIcon';
import Fade from './Fade/Fade';
import './SideFilter.scss';

export default function SideFilter(props: any) {
    // Open & Close Logic >>
    const parent = useRef<HTMLDivElement>(null);
    const closeHandler = (ev: any) => {
        if (!parent.current?.contains(ev.target) && props.isOpen) {
            props.onClose();
        }
    };

    useEffect(() => {
        document.addEventListener('click', closeHandler);
        return () => document.removeEventListener('click', closeHandler);
    });

    // Accordeon logic >>

    return (
        <Fade show={props.isOpen}>
            <div ref={parent} className="sidefilter__wrapper">
                <div className="sidefilter__header">
                    <SideNavIcon linkName={props.iconName} style={{ width: '15px', height: '15px' }} />
                    <span className="header__title">Настройки фильтра</span>
                    <i className="pi pi-times header__close" onClick={props.onClose} />
                </div>
                <div className="sidefilter__content">
                    {props.children}
                    <div className="content__items">
                        <Button label="Сбросить" onClick={props.onClose} />
                        <Button className="save__btn" label="Применить" onClick={() => console.log('send request')} />
                    </div>
                </div>
            </div>
        </Fade>
    );
}
