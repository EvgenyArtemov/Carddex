import React from 'react';
import './SettingsAboutProgram.scss';

const SettingsAboutProgram = () => {
    return (
        <div className="settings-about-program">
            <span>123</span>
        </div>
    );
};

export default SettingsAboutProgram;
