// import { divide } from 'lodash';
// @ts-nocheck
import React, { useState } from 'react';
import './Tabs.scss';

export const Tabs = (props: any) => {
    const [activeTab, setActiveTab] = useState(1);
    const onTabClick = (index: any) => {
        setActiveTab(index);
    };
    return (
        <>
            <div className="tabs">
                {props.children.map((child: any, index: number) => {
                    return (
                        <div
                            onClick={() => onTabClick(index)}
                            key={index}
                            className={`tab ${activeTab === index ? 'active' : ''}`}
                        >
                            {child.props.header}
                        </div>
                    );
                })}
            </div>
            <div className="tab__content">
                {props.children.map((child: any, tabIndex: any) => {
                    return React.cloneElement(child, { activeTab, tabIndex, key: tabIndex });
                })}
            </div>
        </>
    );
};
