import React from 'react';
import './ClassesPage.scss';

export const ClassesPage = () => {
    return (
        <section className="monitoring-params__content">
            {/* <div className="content__header">
                <h2>Классы</h2>
            </div> */}
            <div className="content__items">Наполнение страницы</div>
        </section>
    );
};
