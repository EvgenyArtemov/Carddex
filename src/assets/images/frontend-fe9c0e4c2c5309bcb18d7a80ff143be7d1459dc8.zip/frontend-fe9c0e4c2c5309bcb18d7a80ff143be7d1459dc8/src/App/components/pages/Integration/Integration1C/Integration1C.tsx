import React from 'react'

const Integration1C = () => {
    return (
        <div>123</div>
    )
}

export default Integration1C
