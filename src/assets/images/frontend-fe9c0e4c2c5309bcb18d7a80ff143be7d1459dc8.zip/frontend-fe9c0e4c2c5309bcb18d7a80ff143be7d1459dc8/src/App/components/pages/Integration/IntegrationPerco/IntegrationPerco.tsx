import React from 'react'

const IntegrationPerco = () => {
    return (
        <div>123</div>
    )
}

export default IntegrationPerco