import {
    SecurityPostMonitoringState,
    SecurityPostMonitoringActions,
    GET_SECURITY_POST_MONITORING_EVENTS
} from './securityPostMonitoringTypes';

const initialState: SecurityPostMonitoringState = {
    events: []
};

const SecurityPostMonitoringReducer = (
    state = initialState,
    action: SecurityPostMonitoringActions
): SecurityPostMonitoringState => {
    switch (action.type) {
        case GET_SECURITY_POST_MONITORING_EVENTS: {
            return {
                ...state,
                events: action.payload
            };
        }
        default:
            return state;
    }
};

export default SecurityPostMonitoringReducer;
