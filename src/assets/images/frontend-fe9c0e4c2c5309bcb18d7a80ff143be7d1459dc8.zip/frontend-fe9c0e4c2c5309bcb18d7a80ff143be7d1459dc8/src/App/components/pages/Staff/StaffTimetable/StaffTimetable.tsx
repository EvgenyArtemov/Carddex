import React from 'react';
import './StaffTimetable.scss';

const StaffTimetable = () => {
    return (
        <div className="staff-timetable">
            <h1>Скоро тут будут</h1>
            <p>"Графики работы"</p>
        </div>
    );
};

export default StaffTimetable;
