import React from 'react';
import './SchoolchildSchools.scss';

const SchoolchildSchools = () => {
    return (
        <div className="schoolchild-schools">
            <h1>Скоро тут будут</h1>
            <p>"Школы"</p>
        </div>
    );
};

export default SchoolchildSchools;
