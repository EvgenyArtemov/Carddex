import {
    StaffEmployeesState,
    StaffEmployeesActions,
    GET_STAFF_EMPLOYEES
} from './staffEmployeesTypes';

const initialState: StaffEmployeesState = {
    staffEmployees: []
};

const staffEmployees = (state = initialState, action: StaffEmployeesActions): StaffEmployeesState => {
    switch (action.type) {
        case GET_STAFF_EMPLOYEES:
            return {
                ...state,
                staffEmployees: action.payload
            };
        default:
            return state;
    }
};

export default staffEmployees;
