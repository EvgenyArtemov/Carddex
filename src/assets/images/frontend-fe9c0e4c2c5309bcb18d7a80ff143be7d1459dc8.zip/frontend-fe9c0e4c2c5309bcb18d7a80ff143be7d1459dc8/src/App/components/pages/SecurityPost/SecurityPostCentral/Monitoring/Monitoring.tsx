import React, { useState, memo } from 'react';
import { useDispatch, useSelector, shallowEqual } from 'react-redux';
import { State } from 'App/../redux/store';
import { TabBar } from 'App/components/global/TabBar/TabBar';
import { securityPostCentralToggleBottombar } from '../securityPostCentralAction';
import { Equipments } from './Equipments/Equipments';
import { VideoMonitoring } from './VideoMonitoring/VideoMonitoring';
import { GraphicPlan } from './GraphicPlan/GraphicPlan';
import { Bottombar } from './Bottombar/Bottombar';
import './Monitoring.scss';

const MonitoringInner = () => {
    const dispatch = useDispatch();
    const { bottombarOpened } = useSelector((state: State) => state.postCental, shallowEqual);
    const { toggleBar } = useSelector((state: State) => state.app, shallowEqual);
    const [tab, setTab] = useState(1);
    const [tabs] = useState([
        { index: 1, name: 'Управление' },
        { index: 2, name: 'Видеонаблюдение' },
        { index: 3, name: 'Графический план' },
        { index: 4, name: 'Графический план' },
        { index: 5, name: 'Графический план' },
        { index: 6, name: 'Графический план' }
    ]);

    return (
        <div className="monitoring">
            <TabBar tabPosition={tab} setTab={setTab} tabs={tabs} trigger={toggleBar} />

            <div className="bookmarks-control">
                {tab === 1 && <Equipments />}
                {tab === 2 && <VideoMonitoring />}
                {tab === 3 && <GraphicPlan />}
                {tab === 4 && <GraphicPlan />}
                {tab === 5 && <GraphicPlan />}
                {tab === 6 && <GraphicPlan />}
            </div>

            <Bottombar
                icon="Pie"
                bottombarName="Зональность территории и статистика"
                isOpen={bottombarOpened}
                sidebarToggler={() => dispatch(securityPostCentralToggleBottombar())}
            />
        </div>
    );
};

export const Monitoring = memo(MonitoringInner);
