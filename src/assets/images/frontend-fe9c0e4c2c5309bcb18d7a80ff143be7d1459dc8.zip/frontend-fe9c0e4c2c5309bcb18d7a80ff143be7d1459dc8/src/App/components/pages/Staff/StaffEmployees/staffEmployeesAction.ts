import axios from 'axios';
import { Dispatch } from 'react';
import config from '../../../../../config/config.json';
import { StaffEmployeesActions, StaffEmployees, GET_STAFF_EMPLOYEES } from './staffEmployeesTypes';

export const getStaffEmployees = (employees: StaffEmployees): StaffEmployeesActions => ({
    type: GET_STAFF_EMPLOYEES,
    payload: employees
});

export const requestEmployees = () => (dispatch: Dispatch<StaffEmployeesActions>) => {
    axios
        .get(`${config.apiUrl}employees`)
        .then((response) => {
            dispatch(getStaffEmployees(response.data.employees));
        })
        .catch((error) => {
            console.log(error);
        });
};
