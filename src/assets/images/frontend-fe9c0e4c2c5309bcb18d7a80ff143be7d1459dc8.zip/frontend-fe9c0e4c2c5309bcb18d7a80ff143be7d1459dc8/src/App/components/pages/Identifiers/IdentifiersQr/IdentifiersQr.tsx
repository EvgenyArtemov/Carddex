import React from 'react';
import './IdentifiersQr.scss';

const IdentifiersQr = () => {
    return (
        <div className="identifiers-qr">
            <span>123</span>
        </div>
    );
};

export default IdentifiersQr;
