import React from 'react';
import './ReportsDiscipline.scss';

const ReportsDiscipline = () => {
    return (
        <div className="reports-discipline">
            <span>123</span>
        </div>
    );
};

export default ReportsDiscipline;
