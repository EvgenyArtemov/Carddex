const deleteText = (deletedElement: string): string => {
    return `Вы уверены, что хотите удалить ${deletedElement}?`;
};

export default deleteText;
