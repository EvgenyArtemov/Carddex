import React from 'react';
import './SettingsProductionCalendar.scss';

const SettingsProductionCalendar = () => {
    return (
        <div className="settings-production-calendar">
            <span>123</span>
        </div>
    );
};

export default SettingsProductionCalendar;
