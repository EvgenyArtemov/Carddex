import React from 'react';
import './ToolbarSeparator.scss';

const ToolbarSeparator = () => <div className="toolbar__content__separator" />;

export default ToolbarSeparator;
