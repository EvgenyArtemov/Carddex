import React, { memo } from 'react';

const UserExitInner = () => {
    return (
        <svg viewBox="0 0 24 24">
            <path fill="none" d="M8,6C6.822,6,6,6.822,6,8s0.822,2,2,2s2-0.822,2-2S9.178,6,8,6z" />
            <path d="M14 11H22V13H14zM8 4C5.72 4 4 5.72 4 8s1.72 4 4 4 4-1.72 4-4S10.28 4 8 4zM8 10c-1.178 0-2-.822-2-2s.822-2 2-2 2 .822 2 2S9.178 10 8 10zM4 18c0-1.654 1.346-3 3-3h2c1.654 0 3 1.346 3 3v1h2v-1c0-2.757-2.243-5-5-5H7c-2.757 0-5 2.243-5 5v1h2V18z" />
        </svg>
    );
};

export const UserExit = memo(UserExitInner);
